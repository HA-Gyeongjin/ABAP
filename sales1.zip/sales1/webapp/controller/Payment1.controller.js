sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/model/json/JSONModel"
    ],
    function(Controller, JSONModel) {
      "use strict";
  
      return Controller.extend("sync.zec.sales1.controller.Payment1", {
        onInit: function () {
            this.getRouter().getRoute("payment1").attachPatternMatched(this._onRouteMatched, this);
        },
        
        _onRouteMatched: function (oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            var aCartItems = JSON.parse(oArgs.cartItems); // 문자열을 JSON 객체로 변환
        
            // 로컬 모델에 카트 데이터 설정
            var oCartModel = new JSONModel({
                cartItems: aCartItems,
                totalPrice: aCartItems.reduce((sum, item) => sum + item.Netpr * item.Quantity, 0)
            });
            this.getView().setModel(oCartModel, "cart");
        }
      });
    }
  );