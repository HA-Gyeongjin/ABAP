sap.ui.define([
	"synczec/sales1/test/unit/controller/Home.controller"
], function () {
	"use strict";
});
